# Mars Exploration — Asset Manifest

All supplied GLB files are copied from the previously prepared original-landmark asset set. The module does not modify or replace their geometry, materials, or transforms.

| File | Purpose |
|---|---|
| `Layered_Hills_Curved_Visual.glb` | Original curved layered-hills visual model |
| `Layered_Hills_Curved_Collider.glb` | Collision proxy for the curved hills |
| `Mars_Impact_Crater_Babylon.glb` | Impact crater visual model |
| `Mars_Impact_Crater_Collider.glb` | Collision proxy for the crater |
| `Layered_Rock_Formation_Babylon.glb` | Layered rock formation visual model |
| `Meteorite_Field_Babylon.glb` | Meteorite field visual model |
| `Mars_Abandoned_Equipment_Site_Babylon.glb` | Fictional abandoned equipment site visual model |
| `Exploration_Beacon.glb` | Optional exploration beacon asset |

Expected landmark centres from the existing camera-only location layout:

- Layered Hills: `(-105, 0, -72)`
- Impact Crater: `(105, 0, -72)`
- Abandoned Equipment Site: `(-112, 0, 82)`
- Layered Rock Formation: `(0, 0, 122)`
- Meteorite Field: `(112, 0, 82)`

The game team should use its own actual transforms if they differ. Collision proxies are supplied as assets only; the game team decides how to register them with its physics/collision system.
