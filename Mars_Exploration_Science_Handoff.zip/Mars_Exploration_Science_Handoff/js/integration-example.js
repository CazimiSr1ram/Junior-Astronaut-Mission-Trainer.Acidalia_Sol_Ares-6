/*
 * TEAM INTEGRATION ADAPTER — example only.
 * Load Babylon.js, your existing game scene/player, then mars-exploration.js,
 * then adapt this file to the actual variable names in your game.
 * This file does NOT create a second player or a second scene.
 */

const marsExploration = new MarsExplorationSystem({
  scene: scene, // existing Babylon scene
  getPlayerPosition: () => astronaut.position, // existing astronaut/player

  // Keep these positions aligned with the existing landmark placement.
  // If your game already has loaded GLB roots, add mesh: existingRoot to each entry.
  locations: [
    { id: 'layered-hills', name: 'Layered Hills', position: [-105, 0, -72], description: 'Explore the original curved layered-hills formation.' },
    { id: 'impact-crater', name: 'Impact Crater', position: [105, 0, -72], description: 'Investigate the impact crater and surrounding ejecta.' },
    { id: 'abandoned-equipment', name: 'Abandoned Equipment Site', position: [-112, 0, 82], description: 'A fictional abandoned field-equipment site.' },
    { id: 'layered-rock', name: 'Layered Rock Formation', position: [0, 0, 122], description: 'Compare the exposed rock layers.' },
    { id: 'meteorite-field', name: 'Meteorite Field', position: [112, 0, 82], description: 'Inspect dark fragments scattered across the plain.' }
  ],

  onResourceCollected: (material, amount) => {
    // Forward to your team's resource/inventory system if approved.
    console.log(`Salvage recovered: ${material} +${amount}`);
    // This module intentionally does not award Solar Cells or Helium-3.
  },
  onNotification: message => console.log('[Mars Exploration]', message)
});

marsExploration.start();

// Save with the team's existing save system:
// saveData.marsExploration = marsExploration.getSaveData();
// Restore after start(): marsExploration.loadSaveData(saveData.marsExploration);
// Clean up when leaving the game scene: marsExploration.dispose();
