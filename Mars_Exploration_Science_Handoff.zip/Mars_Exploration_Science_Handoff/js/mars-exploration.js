/*
 * Mars Exploration & Science System
 * Standalone Babylon.js module. Does not replace the team's scene, player,
 * mission-state, resource system, or original GLB assets.
 *
 * Usage:
 * const mars = new MarsExplorationSystem({
 *   scene,
 *   getPlayerPosition: () => player.position,
 *   locations: [ { id, name, description, mesh } ], // optional existing landmarks
 *   onResourceCollected: (material, amount) => {}, // optional team callback
 *   onNotification: (message) => {}                // optional team notification UI
 * });
 * mars.start();
 */
(function (root) {
  'use strict';

  const DEFAULT_LOCATIONS = [
    { id: 'layered-hills', name: 'Layered Hills', description: 'Sedimentary-looking layers may preserve a record of ancient environmental change.', position: [-42, 0, -24], fact: 'Rock layers can preserve a sequence of geological events. Their order and composition help scientists reconstruct a planet\'s history.' },
    { id: 'rock-formation-west', name: 'Western Rock Formation', description: 'A fractured outcrop with contrasting rock textures.', position: [-18, 0, 32], fact: 'Wind-driven abrasion can slowly shape exposed rocks on Mars. The rate depends on wind, dust and rock properties.' },
    { id: 'rock-formation-east', name: 'Eastern Rock Formation', description: 'A compact outcrop suitable for comparing rock samples.', position: [34, 0, 26], fact: 'Comparing mineral composition across nearby rocks can reveal whether they formed under similar conditions.' },
    { id: 'meteorite-field', name: 'Meteorite Field', description: 'Dark fragments scattered across the plain.', position: [58, 0, -16], fact: 'Meteorites found on Mars can help researchers study impact history and compare material from different parts of the Solar System.' },
    { id: 'impact-crater', name: 'Impact Crater', description: 'An exposed crater rim and ejecta field.', position: [12, 0, -52], fact: 'Impact craters expose material from below the surface and provide clues about the age of a landscape.' },
    { id: 'abandoned-site', name: 'Abandoned Equipment Site', description: 'A fictional, uncrewed equipment cache left by an earlier expedition.', position: [-62, 0, 48], fact: 'This is a fictional mission site created for the game, not a real NASA or other agency location.' }
  ];

  const SAMPLE_DEFS = [
    { type: 'basalt', label: 'Basalt Rock', category: 'ROCK', description: 'A dark volcanic rock sample. Basalt is common in volcanic regions on Earth and is also found on Mars.', colour: '#55443e' },
    { type: 'regolith', label: 'Martian Regolith', category: 'SOIL', description: 'Loose surface material made of dust, sand and broken rock. Regolith is not the same as fertile Earth soil.', colour: '#b96f50' },
    { type: 'dust', label: 'Iron-rich Dust', category: 'DUST', description: 'Fine reddish dust. Iron-bearing minerals contribute to the characteristic colour of the Martian surface.', colour: '#c65e42' },
    { type: 'layered-rock', label: 'Layered Rock Sample', category: 'ROCK', description: 'A sample with visible bands that can be compared to understand how the rock formed.', colour: '#9b7058' },
    { type: 'meteorite', label: 'Meteorite Fragment', category: 'FRAGMENT', description: 'A fictional field sample used to teach how meteorite composition can be studied.', colour: '#39383a' }
  ];

  const FACTS = {
    basalt: { title: 'Basalt and volcanism', text: 'Basalt forms when mafic lava cools. Finding basaltic rocks helps scientists understand volcanic activity and the thermal history of a planet.', verified: 'General planetary-geology fact; confirm the specific sample interpretation with the science team.' },
    regolith: { title: 'What is regolith?', text: 'Regolith is the loose layer of dust, soil and broken rock covering solid bedrock. On Mars it is shaped by impacts, wind and other surface processes.', verified: 'General planetary-science fact; sample composition is fictional.' },
    dust: { title: 'Why is Mars red?', text: 'Iron-bearing minerals in Martian dust and rocks are oxidised. These materials contribute to the rusty red appearance of much of the surface.', verified: 'General planetary-science fact; exact mineralogy varies by location.' },
    'layered-rock': { title: 'Reading rock layers', text: 'Sedimentary layers can form as particles settle and become cemented. Their structures can preserve clues about past water, wind and environmental conditions.', verified: 'General geology fact; do not treat this game sample as evidence of water at a real site.' },
    meteorite: { title: 'Studying meteorites', text: 'Meteorites can preserve material from early Solar System history. Researchers study texture, minerals and chemistry to understand their origin.', verified: 'General planetary-science fact; this game fragment is fictional.' }
  };

  class MarsExplorationSystem {
    constructor(options) {
      if (!options || !options.scene) throw new Error('MarsExplorationSystem requires a Babylon.js scene.');
      this.B = root.BABYLON;
      if (!this.B) throw new Error('Babylon.js must be loaded before mars-exploration.js.');
      this.scene = options.scene;
      this.getPlayerPosition = options.getPlayerPosition || null;
      this.onResourceCollected = options.onResourceCollected || null;
      this.onNotification = options.onNotification || null;
      this.interactionDistance = options.interactionDistance || 4.2;
      this.discoveryDistance = options.discoveryDistance || 13;
      this.locations = (options.locations && options.locations.length ? options.locations : DEFAULT_LOCATIONS).map((loc, i) => this.normaliseLocation(loc, i));
      this.samples = [];
      this.salvage = [];
      this.discovered = new Set();
      this.collectedSamples = new Set();
      this.collectedSalvage = new Set();
      this.analysedSamples = new Set();
      this.materials = { metal: 0, polymer: 0, electronics: 0, ceramic: 0 };
      this.interactables = [];
      this.activeTarget = null;
      this.started = false;
      this.keyHandler = this.handleKeyDown.bind(this);
      this.ui = null;
      this.toastTimer = null;
      this._observer = null;
    }

    normaliseLocation(loc, index) {
      const mesh = loc.mesh || loc.rootMesh || null;
      let p = loc.position;
      if (!p && mesh && mesh.getAbsolutePosition) p = mesh.getAbsolutePosition();
      if (p && typeof p.asArray === 'function') p = p.asArray();
      if (p && !Array.isArray(p)) p = [p.x || 0, p.y || 0, p.z || 0];
      p = p || [index * 14, 0, 0];
      return {
        id: loc.id || `location-${index + 1}`,
        name: loc.name || `Exploration Site ${index + 1}`,
        description: loc.description || 'An area of scientific interest.',
        fact: loc.fact || 'Scientists study landforms, rocks and surface processes to understand the history of Mars.',
        mesh,
        position: new this.B.Vector3(Number(p[0]) || 0, Number(p[1]) || 0, Number(p[2]) || 0)
      };
    }

    start() {
      if (this.started) return this;
      this.started = true;
      this.createUI();
      this.createLocationMarkers();
      this.createFieldSamples();
      this.createSalvageCaches();
      this.createResearchTerminal();
      root.addEventListener('keydown', this.keyHandler);
      this._observer = this.scene.onBeforeRenderObservable.add(() => this.update());
      this.renderUI();
      this.notify('Mars Exploration System online. Explore nearby sites and press E to interact.');
      return this;
    }

    dispose() {
      if (!this.started) return;
      root.removeEventListener('keydown', this.keyHandler);
      if (this._observer) this.scene.onBeforeRenderObservable.remove(this._observer);
      this.interactables.forEach(item => { if (item.mesh && !item.mesh.isDisposed()) item.mesh.dispose(false, true); });
      this.locationMeshes.forEach(m => { if (m && !m.isDisposed()) m.dispose(false, true); });
      if (this.ui && this.ui.root.parentNode) this.ui.root.parentNode.removeChild(this.ui.root);
      this.started = false;
    }

    createMaterial(name, hex, emissive) {
      const mat = new this.B.StandardMaterial(name, this.scene);
      mat.diffuseColor = this.color(hex);
      mat.specularColor = new this.B.Color3(0.12, 0.10, 0.09);
      if (emissive) mat.emissiveColor = this.color(emissive);
      return mat;
    }

    color(hex) { return this.B.Color3.FromHexString(hex); }

    createLocationMarkers() {
      this.locationMeshes = [];
      this.locations.forEach((loc, i) => {
        const beacon = this.B.MeshBuilder.CreateCylinder(`explore-beacon-${loc.id}`, { height: 2.1, diameterTop: 0.08, diameterBottom: 0.5, tessellation: 8 }, this.scene);
        beacon.position.copyFrom(loc.position);
        beacon.position.y += 1.05;
        beacon.material = this.createMaterial(`beacon-mat-${i}`, '#d88b62', '#6c3020');
        beacon.isPickable = false;
        const ring = this.B.MeshBuilder.CreateTorus(`explore-ring-${loc.id}`, { diameter: 2.3, thickness: 0.055, tessellation: 32 }, this.scene);
        ring.position.copyFrom(loc.position); ring.position.y += 0.12; ring.rotation.x = Math.PI / 2;
        ring.material = this.createMaterial(`ring-mat-${i}`, '#e8ad7e', '#7d452a');
        ring.isPickable = false;
        this.locationMeshes.push(beacon, ring);
      });
    }

    createFieldSamples() {
      const placements = [
        [0, -7, 2], [0, 5, -4], [1, -5, 5], [1, 6, 3], [2, 4, -5], [2, -6, -3], [3, 0, 5], [3, 5, -2], [4, -4, 4], [4, 5, 2], [5, -4, -4], [5, 4, 4]
      ];
      placements.forEach((entry, i) => {
        const [locIndex, dx, dz] = entry;
        const def = SAMPLE_DEFS[i % SAMPLE_DEFS.length];
        const loc = this.locations[locIndex % this.locations.length];
        const pos = loc.position.add(new this.B.Vector3(dx, 0, dz));
        const mesh = this.makeRock(`sample-${i + 1}`, def.colour, 0.55 + (i % 3) * 0.12);
        mesh.position.copyFrom(pos); mesh.position.y += 0.42;
        mesh.metadata = { explorationId: `sample-${i + 1}` };
        this.samples.push({ id: `sample-${i + 1}`, def, mesh, position: pos, collected: false });
        this.interactables.push({ id: `sample-${i + 1}`, kind: 'sample', label: def.label, mesh, position: pos, data: this.samples[this.samples.length - 1] });
      });
    }

    makeRock(name, hex, scale) {
      const mesh = this.B.MeshBuilder.CreateIcoSphere(name, { radius: 1, subdivisions: 1 }, this.scene);
      mesh.scaling.set(scale * 1.15, scale * 0.72, scale);
      mesh.rotation.set(Math.random() * 0.3, Math.random() * Math.PI, Math.random() * 0.25);
      mesh.material = this.createMaterial(`${name}-material`, hex);
      mesh.isPickable = false;
      return mesh;
    }

    createSalvageCaches() {
      const defs = [
        { id: 'cache-alpha', materials: { metal: 2, polymer: 1 }, title: 'Tool Crate' },
        { id: 'cache-beta', materials: { electronics: 2, metal: 1 }, title: 'Sensor Components' },
        { id: 'cache-gamma', materials: { ceramic: 2, polymer: 1 }, title: 'Thermal Parts' },
        { id: 'cache-delta', materials: { metal: 2, electronics: 1 }, title: 'Power Unit Parts' }
      ];
      defs.forEach((def, i) => {
        const loc = this.locations[(i + 1) % this.locations.length];
        const pos = loc.position.add(new this.B.Vector3(i % 2 ? 7 : -7, 0, i % 2 ? -5 : 5));
        const crate = this.makeCrate(def.id);
        crate.position.copyFrom(pos); crate.position.y += 0.75;
        const item = { ...def, mesh: crate, position: pos, collected: false };
        this.salvage.push(item);
        this.interactables.push({ id: def.id, kind: 'salvage', label: def.title, mesh: crate, position: pos, data: item });
      });
    }

    makeCrate(name) {
      const rootNode = new this.B.TransformNode(`${name}-root`, this.scene);
      const body = this.B.MeshBuilder.CreateBox(`${name}-body`, { width: 1.7, height: 1.25, depth: 1.35 }, this.scene);
      body.parent = rootNode; body.material = this.createMaterial(`${name}-body-mat`, '#62564c');
      const lid = this.B.MeshBuilder.CreateBox(`${name}-lid`, { width: 1.78, height: 0.16, depth: 1.42 }, this.scene);
      lid.parent = rootNode; lid.position.y = 0.69; lid.material = this.createMaterial(`${name}-lid-mat`, '#a56e4e');
      for (let x of [-0.58, 0.58]) {
        const band = this.B.MeshBuilder.CreateBox(`${name}-band-${x}`, { width: 0.13, height: 1.34, depth: 1.43 }, this.scene);
        band.parent = rootNode; band.position.x = x; band.material = this.createMaterial(`${name}-band-mat-${x}`, '#b9a17b');
      }
      rootNode.isPickable = false;
      return rootNode;
    }

    createResearchTerminal() {
      const loc = this.locations.find(l => l.id === 'abandoned-site') || this.locations[this.locations.length - 1];
      const pos = loc.position.add(new this.B.Vector3(0, 0, -7));
      const rootNode = new this.B.TransformNode('science-terminal-root', this.scene);
      rootNode.position.copyFrom(pos);
      const pedestal = this.B.MeshBuilder.CreateBox('science-terminal-pedestal', { width: 1.5, height: 1.6, depth: 1.0 }, this.scene);
      pedestal.parent = rootNode; pedestal.position.y = 0.8; pedestal.material = this.createMaterial('terminal-pedestal-mat', '#46464a');
      const screen = this.B.MeshBuilder.CreateBox('science-terminal-screen', { width: 1.35, height: 0.9, depth: 0.08 }, this.scene);
      screen.parent = rootNode; screen.position.set(0, 2.05, -0.48); screen.rotation.x = -0.12; screen.material = this.createMaterial('terminal-screen-mat', '#3b8d89', '#1c5556');
      this.terminal = { id: 'science-terminal', mesh: rootNode, position: pos };
      this.interactables.push({ id: 'science-terminal', kind: 'terminal', label: 'Science Research Terminal', mesh: rootNode, position: pos, data: this.terminal });
    }

    handleKeyDown(event) {
      if (event.repeat || event.code !== 'KeyE') return;
      if (this.ui && this.ui.labOpen) { this.closeLab(); return; }
      if (this.activeTarget) this.interact(this.activeTarget);
    }

    getPlayerPositionNow() {
      if (typeof this.getPlayerPosition !== 'function') return null;
      const p = this.getPlayerPosition();
      if (!p) return null;
      return p.position || p;
    }

    distance(a, b) { return this.B.Vector3.Distance(a, b); }

    update() {
      const player = this.getPlayerPositionNow();
      if (!player) return;
      this.locations.forEach(loc => {
        if (!this.discovered.has(loc.id) && this.distance(player, loc.position) <= this.discoveryDistance) {
          this.discovered.add(loc.id);
          this.notify(`Location discovered: ${loc.name}`);
          this.renderUI();
        }
      });
      let closest = null, closestDistance = Infinity;
      this.interactables.forEach(item => {
        if (!item.mesh || item.mesh.isDisposed()) return;
        const removed = (item.kind === 'sample' && item.data.collected) || (item.kind === 'salvage' && item.data.collected);
        if (removed) return;
        const d = this.distance(player, item.position);
        if (d < closestDistance && d <= this.interactionDistance) { closest = item; closestDistance = d; }
      });
      if (closest && (!this.activeTarget || this.activeTarget.id !== closest.id)) {
        this.activeTarget = closest;
        this.showPrompt(`E  ·  ${this.actionLabel(closest)}`);
      } else if (!closest && this.activeTarget) {
        this.activeTarget = null; this.hidePrompt();
      }
    }

    actionLabel(item) {
      if (item.kind === 'sample') return `Collect ${item.label}`;
      if (item.kind === 'salvage') return `Salvage ${item.label}`;
      return 'Open Science Laboratory';
    }

    interact(item) {
      if (!item) return;
      if (item.kind === 'sample') this.collectSample(item.data);
      else if (item.kind === 'salvage') this.collectSalvage(item.data);
      else if (item.kind === 'terminal') this.openLab();
    }

    collectSample(sample) {
      if (sample.collected || this.collectedSamples.has(sample.id)) return;
      sample.collected = true; this.collectedSamples.add(sample.id);
      sample.mesh.setEnabled(false);
      this.hidePrompt(); this.activeTarget = null;
      this.notify(`Sample collected: ${sample.def.label}`);
      this.renderUI();
    }

    collectSalvage(cache) {
      if (cache.collected || this.collectedSalvage.has(cache.id)) return;
      cache.collected = true; this.collectedSalvage.add(cache.id);
      Object.entries(cache.materials).forEach(([material, amount]) => {
        this.materials[material] = (this.materials[material] || 0) + amount;
        if (typeof this.onResourceCollected === 'function') this.onResourceCollected(material, amount);
      });
      cache.mesh.setEnabled(false);
      this.hidePrompt(); this.activeTarget = null;
      const contents = Object.entries(cache.materials).map(([k, v]) => `${k} +${v}`).join(', ');
      this.notify(`Salvage recovered: ${contents}`);
      this.renderUI();
    }

    openLab() {
      if (!this.ui) return;
      this.ui.labOpen = true;
      this.ui.labPanel.hidden = false;
      this.hidePrompt(); this.renderLab();
    }

    closeLab() {
      if (!this.ui) return;
      this.ui.labOpen = false; this.ui.labPanel.hidden = true;
    }

    analyseSample(sampleId) {
      const sample = this.samples.find(s => s.id === sampleId);
      if (!sample || !sample.collected || this.analysedSamples.has(sampleId)) return;
      this.analysedSamples.add(sampleId);
      this.notify(`Analysis complete: ${sample.def.label}`);
      this.renderLab(); this.renderUI();
    }

    renderLab() {
      if (!this.ui) return;
      const collected = this.samples.filter(s => s.collected);
      if (!collected.length) {
        this.ui.labContent.innerHTML = '<p class="mx-muted">No samples available. Collect rock, regolith or dust samples in the field first.</p>';
        return;
      }
      this.ui.labContent.innerHTML = collected.map(s => {
        const fact = FACTS[s.def.type] || { title: 'Sample overview', text: s.def.description, verified: 'Educational summary; confirm with the project science reviewer.' };
        const done = this.analysedSamples.has(s.id);
        return `<article class="mx-lab-card"><div class="mx-lab-head"><strong>${this.escape(s.def.label)}</strong><span>${done ? 'ANALYSED' : 'READY'}</span></div><p>${this.escape(s.def.description)}</p>${done ? `<h4>${this.escape(fact.title)}</h4><p>${this.escape(fact.text)}</p><small>${this.escape(fact.verified)}</small>` : `<button data-analyse="${this.escape(s.id)}" class="mx-btn">Analyse sample</button>`}</article>`;
      }).join('');
      this.ui.labContent.querySelectorAll('[data-analyse]').forEach(btn => btn.addEventListener('click', () => this.analyseSample(btn.dataset.analyse)));
    }

    createUI() {
      const style = document.createElement('style');
      style.textContent = `
      #mars-exploration-ui{font-family:Inter,system-ui,Arial,sans-serif;color:#f5e8dc;position:fixed;inset:0;pointer-events:none;z-index:9998}
      #mars-exploration-ui *{box-sizing:border-box} .mx-panel{pointer-events:auto;background:rgba(22,20,21,.88);border:1px solid rgba(221,157,116,.38);backdrop-filter:blur(10px);border-radius:12px;box-shadow:0 12px 36px #0005}
      #mx-status{position:absolute;top:18px;right:18px;width:270px;padding:14px 16px} .mx-title{font-size:12px;letter-spacing:.16em;color:#e9a77d;font-weight:800;margin:0 0 10px}
      .mx-stat{display:flex;justify-content:space-between;gap:12px;font-size:12px;padding:5px 0;border-bottom:1px solid #ffffff12}.mx-stat:last-child{border:0}
      #mx-objectives{position:absolute;left:18px;top:18px;width:270px;padding:14px 16px}.mx-muted{color:#c3b4aa;font-size:12px;line-height:1.5}
      #mx-prompt{position:absolute;bottom:9%;left:50%;transform:translateX(-50%);padding:11px 18px;border-radius:8px;background:#201b19eF;border:1px solid #d9946d;color:#ffe2ce;font-weight:700;font-size:13px;display:none}
      #mx-toast{position:absolute;bottom:18px;left:50%;transform:translateX(-50%);padding:10px 16px;background:#241d1a;border:1px solid #c98b68;border-radius:8px;font-size:13px;display:none}
      #mx-lab{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(620px,92vw);max-height:78vh;overflow:auto;padding:20px} .mx-lab-card{padding:13px;margin:10px 0;background:#ffffff0a;border:1px solid #ffffff18;border-radius:9px}.mx-lab-head{display:flex;justify-content:space-between;gap:10px}.mx-lab-head span{font-size:10px;color:#e9a77d;letter-spacing:.1em}.mx-lab-card p{font-size:12px;line-height:1.5;color:#d5c5ba}.mx-lab-card h4{margin:10px 0 2px;color:#f2b58d}.mx-lab-card small{color:#b7a69b;font-size:10px;line-height:1.4;display:block}
      .mx-btn{pointer-events:auto;border:1px solid #d9946d;background:#75442f;color:#fff1e8;border-radius:7px;padding:8px 12px;font-weight:700;cursor:pointer}.mx-btn:hover{background:#925b3f}.mx-close{float:right;background:transparent;color:#f5e8dc;border:1px solid #ffffff44;border-radius:6px;padding:5px 9px;cursor:pointer}
      @media(max-width:650px){#mx-status{top:auto;bottom:64px;right:10px;width:205px}#mx-objectives{left:10px;top:10px;width:205px}.mx-stat{font-size:10px}}
      `;
      document.head.appendChild(style);
      const host = document.createElement('div'); host.id = 'mars-exploration-ui';
      host.innerHTML = `
        <section id="mx-objectives" class="mx-panel"><h3 class="mx-title">MISSION OBJECTIVES</h3><div id="mx-objective-list" class="mx-muted"></div></section>
        <section id="mx-status" class="mx-panel"><h3 class="mx-title">FIELD LOG</h3><div id="mx-stats"></div></section>
        <div id="mx-prompt"></div><div id="mx-toast"></div>
        <section id="mx-lab" class="mx-panel" hidden><button class="mx-close" id="mx-close-lab">Close (E)</button><h3 class="mx-title">MARS SCIENCE LABORATORY</h3><p class="mx-muted">Select a collected sample to run a field analysis. Educational interpretations are labelled for science-team review.</p><div id="mx-lab-content"></div></section>`;
      document.body.appendChild(host);
      this.ui = { root: host, prompt: host.querySelector('#mx-prompt'), toast: host.querySelector('#mx-toast'), stats: host.querySelector('#mx-stats'), objectiveList: host.querySelector('#mx-objective-list'), labPanel: host.querySelector('#mx-lab'), labContent: host.querySelector('#mx-lab-content'), labOpen: false };
      host.querySelector('#mx-close-lab').addEventListener('click', () => this.closeLab());
    }

    renderUI() {
      if (!this.ui) return;
      const analysed = this.analysedSamples.size, collected = this.collectedSamples.size;
      this.ui.stats.innerHTML = [
        ['Locations discovered', `${this.discovered.size}/${this.locations.length}`],
        ['Samples collected', `${collected}/${this.samples.length}`],
        ['Samples analysed', `${analysed}/${collected}`],
        ['Salvage caches', `${this.collectedSalvage.size}/${this.salvage.length}`],
        ['Metal', this.materials.metal], ['Polymer', this.materials.polymer], ['Electronics', this.materials.electronics], ['Ceramic', this.materials.ceramic]
      ].map(([k, v]) => `<div class="mx-stat"><span>${this.escape(k)}</span><strong>${this.escape(String(v))}</strong></div>`).join('');
      const objectives = [
        ['Discover exploration sites', this.discovered.size, this.locations.length],
        ['Collect field samples', collected, this.samples.length],
        ['Analyse collected samples', analysed, Math.max(1, collected)],
        ['Recover abandoned equipment', this.collectedSalvage.size, this.salvage.length]
      ];
      this.ui.objectiveList.innerHTML = objectives.map(([label, value, total]) => `<div class="mx-stat"><span>${this.escape(label)}</span><strong>${value}/${total}</strong></div>`).join('');
    }

    showPrompt(text) { if (this.ui) { this.ui.prompt.textContent = text; this.ui.prompt.style.display = 'block'; } }
    hidePrompt() { if (this.ui) this.ui.prompt.style.display = 'none'; }
    notify(message) {
      if (typeof this.onNotification === 'function') this.onNotification(message);
      if (!this.ui) return;
      this.ui.toast.textContent = message; this.ui.toast.style.display = 'block';
      clearTimeout(this.toastTimer); this.toastTimer = setTimeout(() => { if (this.ui) this.ui.toast.style.display = 'none'; }, 2800);
    }
    escape(value) { return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

    getSaveData() {
      return {
        version: 1,
        discovered: [...this.discovered], collectedSamples: [...this.collectedSamples],
        collectedSalvage: [...this.collectedSalvage], analysedSamples: [...this.analysedSamples],
        materials: { ...this.materials }
      };
    }

    loadSaveData(data) {
      if (!data || data.version !== 1) return false;
      this.discovered = new Set(data.discovered || []);
      this.collectedSamples = new Set(data.collectedSamples || []);
      this.collectedSalvage = new Set(data.collectedSalvage || []);
      this.analysedSamples = new Set(data.analysedSamples || []);
      this.materials = { ...this.materials, ...(data.materials || {}) };
      this.samples.forEach(s => { s.collected = this.collectedSamples.has(s.id); if (s.collected) s.mesh.setEnabled(false); });
      this.salvage.forEach(s => { s.collected = this.collectedSalvage.has(s.id); if (s.collected) s.mesh.setEnabled(false); });
      this.renderUI(); return true;
    }
  }

  root.MarsExplorationSystem = MarsExplorationSystem;
})(typeof window !== 'undefined' ? window : globalThis);
