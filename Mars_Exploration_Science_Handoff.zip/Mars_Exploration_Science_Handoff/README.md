# Mars Exploration & Science — Integration Handoff

This package contains the user's Mars Exploration and Science task as a modular Babylon.js handoff. The game team only needs to connect it to its existing scene and astronaut/player controller; it must not create a second scene or player.

## Included gameplay systems

- Five exploration locations aligned with the existing landmark layout.
- Proximity-based location discovery and discovery log.
- Twelve collectible field samples (rock, regolith, dust and fragments).
- E-key interaction, collection notifications and duplicate-collection prevention.
- Four fictional salvage caches and local material counters (metal, polymer, electronics, ceramic).
- Interactive science terminal with sample analysis and educational fact cards.
- Objectives panel, field log, counters, save-data export/import and cleanup method.

## Package layout

```text
Mars_Exploration_Science_Handoff/
├── js/
│   ├── mars-exploration.js
│   └── integration-example.js
├── assets/
│   ├── Layered_Hills_Curved_Visual.glb
│   ├── Layered_Hills_Curved_Collider.glb
│   ├── Mars_Impact_Crater_Babylon.glb
│   ├── Mars_Impact_Crater_Collider.glb
│   ├── Layered_Rock_Formation_Babylon.glb
│   ├── Meteorite_Field_Babylon.glb
│   ├── Mars_Abandoned_Equipment_Site_Babylon.glb
│   └── Exploration_Beacon.glb
└── docs/ASSET_MANIFEST.md
```

## Integration contract

1. Load Babylon.js and create the team's existing `scene` and astronaut/player as usual.
2. Load `js/mars-exploration.js` after Babylon.js.
3. Adapt `js/integration-example.js` to the team's actual variable names and landmark transforms.
4. Construct `MarsExplorationSystem` with the existing scene and `getPlayerPosition: () => existingPlayer.position`.
5. Call `start()` once. The module handles its own E-key listener and per-frame proximity updates.
6. Optionally connect `onResourceCollected` and `onNotification` to team systems.
7. Save/restore with `getSaveData()` and `loadSaveData(data)`; call `dispose()` when unloading the scene.

## Preservation and boundaries

- Original GLB assets are included unchanged in this package; the module does not load, recolour, resize, rename or replace them.
- The module creates only its own lightweight sample props, salvage props, lab terminal, markers and UI.
- It does not create a player, movement controller, camera, terrain, scene, mission-state manager or separate resource economy.
- It does not award Solar Cells, Helium-3, upgrades or mission currency. Salvage materials are tracked locally and optionally emitted through a callback.
- The abandoned equipment site and sample placements are fictional gameplay content, not claims about real NASA/agency locations or actual measurements.
- Educational facts are general science summaries and should be reviewed by the project science/content owner before public release.

## Controls

Walk near a sample, salvage cache, or science terminal and press **E**. Discovery is triggered by entering the configured discovery radius.

## Notes for the integrating team

The module assumes the player's position is available as a Babylon `Vector3`. If the game uses a different coordinate convention, adapt the position callback and location coordinates. The module's UI is injected into the document and uses its own CSS namespace (`mx-`). Check for keyboard conflicts with the game's existing E-key handler and coordinate input ownership if necessary.
